CHANGELOG
=========

6.4
---

* Deprecate the component, use Twig instead

2.5.0
-----

 * added ability to generate versioned URLs
 * added ability to generate absolute URLs

2.1.0
-----

 * added StreamingEngineInterface
 * added ENT_SUBSTITUTE for the HTML escaper
